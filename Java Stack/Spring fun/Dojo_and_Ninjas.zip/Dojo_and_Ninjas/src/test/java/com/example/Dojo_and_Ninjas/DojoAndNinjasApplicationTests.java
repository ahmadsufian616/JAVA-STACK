package com.example.Dojo_and_Ninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoAndNinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
